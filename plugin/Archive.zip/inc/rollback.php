<?php
// TODO: Rollback utilities for applied fixes.

